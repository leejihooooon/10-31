package kr.ac.mjc.photo

import java.util.*

class Photo(var description:String="", var downloadUrl:String?=null, var date: Date=Date(), var id:String="") {

}